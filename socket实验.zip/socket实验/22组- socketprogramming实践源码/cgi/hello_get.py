#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#
#   This script does not provide a valid CGI response or a valid HTTP/1.1
#   response.  In fact, it does not even produce valid HTML.  It is meant to
#   help you investigate the variables and other parameters your server is
#   passing to the script.  You may want to turn the prints into writes to a
#   a log file especially when you start redirecting stdout of the script.
#
#   Authors: Athula Balachandran <abalacha@cs.cmu.edu>
#            Charles Rang <rang@cs.cmu.edu>
#            Wolfgang Richter <wolf@cs.cmu.edu>
import os,sys
os.chdir(sys.path[0])

import sys
from os import environ

import cgi, cgitb 

form = cgi.FieldStorage() 
site_name = form.getvalue('username')
site_password  = form.getvalue('password')

print ("HTTP/1.1 200 OK\r\n"),
print ("Content-type:text/html")
print
print ("""<!DOCTYPE html>""")
print ("""<html lang="en">""")

print ("""<head>""")
print ("""  <meta charset="UTF-8">""")
print ("""  <meta name="viewport" content="width=device-width, initial-scale=1.0">""")
print ("""  <title>Document</title>""")
print ("""  <style>""")
print ("""    body {""")
print ("""      background: url('https://cdn.pixabay.com/photo/2018/08/14/13/23/ocean-3605547_1280.jpg') no-repeat;""")
print ("""      background-size: 100% 130%;""")
print ("""    }""")

print ("""    #login_box {""")
print ("""      width: 20%;""")
print ("""      height: 400px;""")
print ("""      background-color: #00000060;""")
print ("""      margin: auto;""")
print ("""      margin-top: 10%;""")
print ("""      text-align: center;""")
print ("""      border-radius: 10px;""")
print ("""      padding: 50px 50px;""")
print ("""    }""")

print ("""    h2 {""")
print ("""      color: #ffffff90;""")
print ("""      margin-top: 5%;""")
print ("""    }""")

print ("""h3 {""")
print ("""      color: #ffffff90;""")
print ("""      margin-top: 5%;""")
print ("""    }""")
print ("""h4 {""")
print ("""      color: #ffffff90;""")
print ("""      margin-top: 5%;""")
print ("""    }""")
print ("""    #input-box {""")
print ("""      margin-top: 5%;""")
print ("""    }""")

print ("""    span {""")
print ("""      color: #fff;""")
print ("""    }""")

print ("""    input {""")
print ("""      border: 0;""")
print ("""      width: 60%;""")
print ("""      font-size: 15px;""")
print ("""      color: #fff;""")
print ("""      background: transparent;""")
print ("""      border-bottom: 2px solid #fff;""")
print ("""      padding: 5px 10px;""")
print ("""      outline: none;""")
print ("""      margin-top: 10px;""")
print ("""    }""")

print ("""    button {""")
print ("""      margin-top: 50px;""")
print ("""      width: 60%;""")
print ("""      height: 30px;""")
print ("""      border-radius: 10px;""")
print ("""      border: 0;""")
print ("""      color: #fff;""")
print ("""      text-align: center;""")
print ("""      line-height: 30px;""")
print ("""      font-size: 15px;""")
print ("""      background-image: linear-gradient(to right, #30cfd0, #330867);""")
print ("""    }""")

print ("""    #sign_up {""")
print ("""      margin-top: 45%;""")
print ("""      margin-left: 60%;""")
print ("""    }""")

print ("""    a {""")
print ("""      color: #b94648;""")
print ("""    }""")
print ("""  </style>""")
print ("""</head>""")

print ("""<body>""")
print ("""  <div id="login_box">""")
print ("""    <h2>LOGIN</h2>""")
print ("""    <h4>姓名输入成功!<h4/>""")

print ("""<h3>姓名为%s</h3>""")%(site_name)   
print ("""<h4>密码输入成功!<h4/>""")
print ("""<h3>密码为%s</h3>""")%(site_password)   
 
print ("""    <h2>登录成功</h2><br>""")
print ("""  </div>""")
print ("""</body>""")
print ("""</html>""")

