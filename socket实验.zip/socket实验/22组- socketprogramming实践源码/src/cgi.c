#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include "cgi.h"
#include "log.h"

CGI_envp *new_cgi_envp()
{
	CGI_envp *cgi_envp = (CGI_envp *)malloc(sizeof(CGI_envp));

	// cgi_envp->capacity = 20 ;
	cgi_envp->size = 0;
	// if ((cgi_envp->envp = (char **) malloc (cgi_envp->capacity * sizeof(char **))) == NULL)
	//	return NULL ;

	cgi_envp->envp[0] = NULL;
	return cgi_envp;
}

void free_cgi_envp(CGI_envp *cgi_envp)
{
	int i;

	for (i = 0; i < cgi_envp->size; i++)
		free(cgi_envp->envp[i]);

	// free (cgi_envp->envp) ;
	free(cgi_envp);
}

int fill_cgi_envp(CGI_envp *cgi_envp, const char *name, const char *value)
{
	/*if (cgi_envp->size + 1 == cgi_envp->capacity)
	{
		cgi_envp->capacity <<= 1 ;
		if ((cgi_envp->envp = (char **) realloc (cgi_envp->envp, cgi_envp->capacity * sizeof(char **))) == NULL)
		{
			LOG_ERR ("Can not alloc envp for cgi.") ;
			return -1 ;
		}
	}*/

	if ((cgi_envp->envp[cgi_envp->size] = (char *)malloc(strlen(name) + strlen(value) + 2)) == NULL)
	{
		LOG_ERR("Can not alloc envp for cgi.");
		return -1;
	}

	strcpy(cgi_envp->envp[cgi_envp->size], name);
	strcat(cgi_envp->envp[cgi_envp->size], "=");
	strcat(cgi_envp->envp[cgi_envp->size], value);

	cgi_envp->size++;
	cgi_envp->envp[cgi_envp->size] = NULL;
	return 0;
}

char *get_cgi_query(char *req_path)
{
	char *qmark = strstr(req_path, "?");

	if (qmark)
		return qmark + 1;
	return NULL;
}

CGI *new_cgi(char *argv[], CGI_envp *cgi_envp,char* buffer)
{
	CGI *cgi;
	memset(buffer, 0, 9999);
	int stdin_pipe[2];
	int stdout_pipe[2];
	char buf[4096];
	char POST_BODY[4096];
	int readret;

	if (argv[0] == NULL)
	{
		LOG_ERR("No CGI filename in the argument.");
		return NULL;
	}

	if (pipe(stdin_pipe) < 0)
	{
		LOG_ERR("Error piping for stdin.");
		return NULL;
	}

	if (pipe(stdout_pipe) < 0)
	{
		LOG_ERR("Error piping for stdout.");
		return NULL;
	}

	switch (fork())
	{
	case -1:
		LOG_ERR("Faild to fork.");
		return NULL;
	case 0:
		close(stdout_pipe[0]);
		close(stdin_pipe[1]);
		dup2(stdin_pipe[0], STDIN_FILENO);
		dup2(stdout_pipe[1], STDOUT_FILENO);
		if (execve(argv[0], argv, cgi_envp->envp))
		{
			memset(buffer,0,9999);
			strcpy(buf,"HTTP/1.1 500 Internal Server Error\r\n");
			LOG_ERR("Error execute CGI [%s].", argv[0]);
			LOG_PRINT(LOG_ERROR, " [client 4]\r\n\t[500 Internal Server Error] The server internal resource (cgi) failed to execute the request.");
			LOG_Destroy();
			free_cgi(cgi);
			return NULL;
		}
	default:
		close(stdout_pipe[1]);
		close(stdin_pipe[0]);
		cgi = (CGI *)malloc(sizeof(CGI));
		if (write(stdin_pipe[1], POST_BODY, strlen(POST_BODY)) < 0)
		{
			LOG_ERR("Error writing to spawned CGI program.");
			return EXIT_FAILURE;
		}

		close(stdin_pipe[1]); /* finished writing to spawn */
		while ((readret = read(stdout_pipe[0], buf, 4096 - 1)) > 0)
		{
			buf[readret] = '\0'; 
			strcat(buffer,buf);
		}

		close(stdout_pipe[0]);
		close(stdin_pipe[1]);

		if (readret == 0)
		{
			strcat(buf,"\r\n");
			//fprintf(stdout, "CGI spawned process returned with EOF as expected.\n");
		}
		cgi->in = stdout_pipe[0];
		cgi->out = stdin_pipe[1];
	}

	return cgi;
}

void free_cgi(CGI *cgi)
{
	close(cgi->in);
	close(cgi->out);
	free(cgi);
}


void handle_cgi(Request *request, char *buf)
{
    char req_path[4096], port_str[8], *argv[2];
    char *cgi_filename, *cgi_query;
    CGI_envp *cgi_envp;

    strcpy(req_path, "./cgi/");
    strcat(req_path, request->http_uri + 5);

    cgi_query = get_cgi_query(req_path);
    if (cgi_query)
        cgi_query[-1] = '\0';

    cgi_filename = req_path;
    if (access(cgi_filename, F_OK | R_OK) < 0)
    {
		strcpy(buf,"HTTP/1.1 404 Not Found\r\n");
		file_status(cgi_filename,4);
        return;
    }

    if ((cgi_envp = new_cgi_envp()) == NULL)
    {
        LOG_ERR("Can not alloc envp for cgi.");
        return;
    }
    char conten_length[10];

    sprintf(conten_length, "%d", request->content_length);
    fill_cgi_envp(cgi_envp, "CONTEN_LENGTH", conten_length);
    fill_cgi_envp(cgi_envp, "REQUEST_METHOD", request->http_method);
    if (cgi_query&&(!strcmp(request->http_method,"GET")))
        fill_cgi_envp(cgi_envp, "QUERY_STRING", cgi_query);
	if (!strcmp(request->http_method,"POST"))
        fill_cgi_envp(cgi_envp, "QUERY_STRING",request->message_body );
    fill_cgi_envp(cgi_envp, "SCRIPT_NAME", cgi_filename);
    sprintf(port_str, "%d", 9999);
    fill_cgi_envp(cgi_envp, "SERVER_PORT", port_str);
    if (get_header(request, "Accept"))
        fill_cgi_envp(cgi_envp, "HTTP_ACCEPT", get_header(request, "Accept"));
    fill_cgi_envp(cgi_envp, "SERVER_PROTOCOL", "HTTP/1.1");
    fill_cgi_envp(cgi_envp, "SERVER_NAME", "Liso/1.0");
    fill_cgi_envp(cgi_envp, "SERVER_SOFTWARE", "Liso/1.0");
    fill_cgi_envp(cgi_envp, "GATEWAY_INTERFACE", CGI_VERSION);
    fill_cgi_envp(cgi_envp, "REMOTE_ADDR", "127.0.0.1");
    fill_cgi_envp(cgi_envp, "REMOTE_HOST", "localhost");
    fill_cgi_envp(cgi_envp, "REQUEST_URI", request->http_uri);
    fill_cgi_envp(cgi_envp, "SCRIPT_NAME", CGI_VERSION);
    if (get_header(request, "Referer"))
        fill_cgi_envp(cgi_envp, "HTTP_REFERER", get_header(request, "Referer"));
    if (get_header(request, "Accept-Encoding"))
        fill_cgi_envp(cgi_envp, "HTTP_ ACCEPT_ENCODING", get_header(request, "Accept-Encoding"));
    if (get_header(request, "Accept-Language"))
        fill_cgi_envp(cgi_envp, "HTTP_ACCEPT_LANGUAGE", get_header(request, "Accept-Language"));
    if (get_header(request, "Accept-Charset"))
        fill_cgi_envp(cgi_envp, "HTTP_ACCEPT_CHARSET", get_header(request, "Accept-Charset"));
    if (get_header(request, "Cookie"))
        fill_cgi_envp(cgi_envp, "HTTP_COOKIE", get_header(request, "Cookie"));
    if (get_header(request, "User-Agent"))
        fill_cgi_envp(cgi_envp, "HTTP_USER_AGENT", get_header(request, "User-Agent"));
    if (get_header(request, "Connection"))
        fill_cgi_envp(cgi_envp, "HTTP_CONNECTION", get_header(request, "Connection"));

    argv[0] = cgi_filename;
    argv[1] = NULL;

    CGI *cgi = new_cgi(argv, cgi_envp, buf);
    if (cgi == NULL)
    {
        LOG_ERR("Faild to create CGI [%s].", req_path);
        return;
    }

    free_cgi_envp(cgi_envp);
	close(cgi->out);
    free_cgi(cgi);
    return;
}


char *get_header(Request *requset, char *name)
{
    int i;
    for (i = 0; i < requset->header_count; i++)
        if (!strcmp(requset->headers[i].header_name, name))
            return requset->headers[i].header_value;

    return NULL;
}
