/******************************************************************************
 * echo_server.c                                                               *
 *                                                                             *
 * Description: This file contains the C source code for an echo server.  The  *
 *              server runs on a hard-coded port and simply write back anything*
 *              sent to it by connected clients.  It does not support          *
 *              concurrent clients.                                            *
 *                                                                             *
 * Authors: Athula Balachandran <abalacha@cs.cmu.edu>,                         *
 *          Wolf Richter <wolf@cs.cmu.edu>                                     *
 *                                                                             *
 *******************************************************************************/

#include <netinet/in.h>
#include <netinet/ip.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
//#include "parse.h"
#include "respond.h"
#include "log.h"

#define ECHO_PORT 9999
#define BUF_SIZE 9999

// char PATH0[4196];
// char PATH[4196] = "./static_site";

int close_socket(int sock)
{
    if (close(sock))
    {
        fprintf(stderr, "Failed closing socket.\n");
        // LOG_INFO()
        return 1;
    }

    return 0;
}

int main(int argc, char *argv[])
{
    LOG_SetPrintLogPlaceFlag(1);
    LOG_Init("run", 8000);
    int sock = 0, client_sock = 0;
    int set[1] = {0};
    ssize_t readret;
    socklen_t cli_size;
    struct sockaddr_in addr, cli_addr;
    char buf[BUF_SIZE];
    char again_buf[BUF_SIZE];
    memset(again_buf, 0, 4096);

    fprintf(stdout, "----- Echo Server -----\n");
    /* all networked programs must create a socket */
    if ((sock = socket(PF_INET, SOCK_STREAM, 0)) == -1)
    {
        LOG_ERR("%s", "Failed creating socket.");
        return EXIT_FAILURE;
    }

    addr.sin_family = AF_INET;         // IPv4
    addr.sin_port = htons(ECHO_PORT);  // port
    addr.sin_addr.s_addr = INADDR_ANY; // ip =0.0.0.0

    /* servers bind sockets to ports---notify the OS they accept connections */
    if (bind(sock, (struct sockaddr *)&addr, sizeof(addr)))
    {
        close_socket(sock);
        LOG_ERR("%s", "Failed binding socket.");
        return EXIT_FAILURE;
    }

    if (listen(sock, 1024))
    {
        close_socket(sock);
        LOG_ERR("%s", "Error listening on socket.");
        return EXIT_FAILURE;
    }
    /*
    int optval=1824*940*10;
   int optLEn=sizeof(int);
    setsockopt(sock,SOL_SOCKET,SO_RCVBUF,(char*)&optval,optLEn);
*/
    fd_set current_sockets, ready_sockets;

    FD_ZERO(&current_sockets);
    FD_SET(sock, &current_sockets);

    while (1)
    {
        ready_sockets = current_sockets;
        int ready_num = select(FD_SETSIZE, &ready_sockets, NULL, NULL, NULL);
        if (ready_num < 0)
        {
            LOG_ERR("%s", "Error select.\n");
            return EXIT_FAILURE;
        }
        for (int i = 0; i < FD_SETSIZE; i++)
        {
            if (FD_ISSET(i, &ready_sockets))
            {
                if (i == sock)
                {
                    if ((client_sock = accept(sock, (struct sockaddr *)&cli_addr,
                                              &cli_size)) == -1)
                    {
                        close(sock);
                        LOG_ERR("%s", "Error accepting connection.");
                        return EXIT_FAILURE;
                    }
                    FD_SET(client_sock, &current_sockets);
                }
                else
                {
                    fcntl(i, F_SETFL, fcntl(i, F_GETFL, 0) | O_NONBLOCK);
                    handle_connection(i, sock);
                    fcntl(i, F_SETFL, fcntl(i, F_GETFL, 0) & ~O_NONBLOCK);
                    FD_CLR(i, &current_sockets);
                    if (close_socket(i))
                    {
                        // close_socket(sock);
                        LOG_ERR("%s", "Error closing client socket.");
                        // return EXIT_FAILURE;
                    }
                }
            }
        }
    }

    close_socket(sock);

    return EXIT_SUCCESS;
}
