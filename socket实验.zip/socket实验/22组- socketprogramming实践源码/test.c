#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <sys/stat.h> 
#include <time.h>
#include "include/log.h"

#define ECHO_PORT 9999
#define BUF_SIZE 29999

int main(){
	FILE *pfile;
  char PATH[]="/home/lll/websever/static_site/images/liso_header.png";
    pfile = fopen(PATH, "r");
    fseek(pfile, 0, SEEK_END);
    int length = ftell(pfile);
    rewind(pfile);
    char buf[BUF_SIZE];
    length = fread(buf ,1, length, pfile);
    printf("%d\n",length);
    buf[length] = '\0';
    printf("%s",buf);
    fclose(pfile);
}