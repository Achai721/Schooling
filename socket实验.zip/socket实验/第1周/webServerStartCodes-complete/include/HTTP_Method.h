#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#define GET "GET"
#define HEAD "HEAD"
#define POST "POST"

int process_method(char []);