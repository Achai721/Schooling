#include "HTTP_Method.h"

int process_method(char a[]){
    if(strcmp(a,GET)==0)
        return 1;
    if(strcmp(a,HEAD)==0)
        return 2;
    if(strcmp(a,POST)==0)
        return 3;
    return 0;
}