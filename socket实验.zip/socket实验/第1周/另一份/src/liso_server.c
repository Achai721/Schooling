#include <netinet/in.h>
#include <netinet/ip.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/sendfile.h>
#include "parse.h"
#include <sys/select.h>

#define CONTENT_LENGTH 5
#define BUF_SIZE 9999
#define ECHO_PORT 9999
#define MAX_CLIENTS 1024

int handle_request(char* buf, int client_sock, ssize_t readret[1]);

//length of response entity
size_t contentlength(const char* path) {
  struct stat st;
  stat(path, &st);
  return st.st_size;
}

//get current time
void date(char *time_buf, size_t buf_size) {
  time_t raw_time;
  struct tm * timeinfo;

  time(&raw_time);
  timeinfo = localtime(&raw_time);
  strftime(time_buf, buf_size, "%a, %d %b %Y %H:%M:%S %Z\r\n", timeinfo);
}

//get the extension of response file(site)
void extension(const char *path, char *result)
{
    size_t len = strlen(path);
    for (int i = len - 1; i >= 0; i--)
    {
        int curr_len = len - i;
        if (path[i] == '.')
        {
            strcat(result, path + (len - curr_len) + 1);
            return;
        }
    }
    strncpy(result, "none", 4);
}

//get the type of response file(site)
void contenttype(const char *mime, char *type)
{
    if (!strcmp(mime, "html"))
    {
        strcpy(type, "text/html");
    }
    else if (!strcmp(mime, "css"))
    {
        strcpy(type, "text/css");
    }
    else if (!strcmp(mime, "png"))
    {
        strcpy(type, "image/png");
    }
    else if (!strcmp(mime, "jpeg"))
    {
        strcpy(type, "image/jpeg");
    }
    else if (!strcmp(mime, "gif"))
    {
        strcpy(type, "image/gif");
    }
    else
    {
        strcpy(type, "unknown");
    }
}

//get the last modified time of the requested file
void lastmodified(const char*path, char *last_mod_time, size_t buf_size) {
  struct stat st;
  struct tm *curr_gmt_time = NULL;
  stat(path, &st);
  curr_gmt_time = gmtime(&st.st_mtime);
  strftime(last_mod_time, buf_size, "%a, %d %b %Y %H:%M:%S %Z\r\n", curr_gmt_time);
}

//response to the method HEAD
int response(char* buf, char* path, int sock){
    //if the requested file exists or not
    if (access(path, F_OK) < 0){
        return 1;
    }

    //if the requested file can be read/excuted or not
    if (access(path, R_OK | X_OK) < 0){
        return 1;
    }

    //response line

    strcpy(buf,"HTTP/1.1 200 OK\r\nServer: liso/1.0\r\n");

    //Date
    char timebuf[33];
    date(timebuf,33);
    strcat(buf,"Date: ");
    strcat(buf, timebuf);

    //Content-Length
    int content_len = contentlength(path);
    char contentlen[CONTENT_LENGTH];
    sprintf(contentlen, "%d", content_len);
    strcat(buf, "Content-Length: ");
    strcat(buf, contentlen);

    //Content-Type
    char type[10];
    char extens[4];
    memset(extens, 0, 4);
    extension(path, extens);
    contenttype(extens, type);
    strcat(buf, "\r\nContent-Type: ");
    strcat(buf, type);

    //Last-Modified
    char timebuf2[33];
    lastmodified(path,timebuf2,33);
    strcat(buf, "\r\nLast-Modified: ");
    strcat(buf, timebuf2);

    //Connect
    strcat(buf,"Connect: Keep-Alive\r\n");

    return 0;
}

int handle_request(char* buf, int client_sock, ssize_t readret[1]){
    readret[0] = 0;
    char buff[BUF_SIZE];
    memset(buff, 0, BUF_SIZE);
    int len[1] = {0};

        memset(buf, 0, BUF_SIZE);

        while((readret[0] = recv(client_sock, buf, BUF_SIZE, 0)) >= 1)
        {
            while(1){
               // fprintf(stdout, "NO.%d request\r\nFrom sock %d\r\n", cnt[0]++,client_sock);
                Request* request = parse(buf, strlen(buf),client_sock,len);
                memset(buff, 0, BUF_SIZE);
                strcat(buff, buf + len[0]);
                len[0] = 0;
                memset(buf, 0, BUF_SIZE);
                if (request == NULL){
                    send(client_sock, "HTTP/1.1 400 Bad Request\r\n\r\n", 28, 0);
                    fprintf(stdout, "HTTP/1.1 400 Bad Request\r\n\r\n");
                }
                else{
                    if(strcmp(request->http_version,"HTTP/1.1")){
                        send(client_sock, "HTTP/1.1 505 HTTP Version not supported\r\n\r\n", 47, 0);
                        fprintf(stdout, "HTTP/1.1 505 HTTP Version not supported\r\n\r\n");
                    }
                    else if (!strcmp(request->http_method,"GET")||!strcmp(request->http_method,"HEAD")||!strcmp(request->http_method,"POST"))
                    {
                        char path[100];
                        memset(path, 0, 100);
                        strcpy(path, "./static_site");
                        strcat(path, request->http_uri);
                        strcat(path, "index.html");
                        if(!strcmp(request->http_method,"GET")){
                            if (response(buf, path, client_sock)){
                                send(client_sock, "HTTP/1.1 404 Not Found\r\n\r\n", 30, 0);
                                fprintf(stdout, "HTTP/1.1 404 Not Found\r\n\r\n");
                            }
                            else{
                                send(client_sock, buf, strlen(buf), 0);
                                int content_len = contentlength(path);
                                int fd = open("./static_site/index.html", O_RDONLY);
                                sendfile(client_sock, fd, NULL, content_len);
                                //send_file(client_sock, path, buf);
                                fprintf(stdout, "GET OK\r\n\r\n");
                                }                            
                        }
                        else if(!strcmp(request->http_method,"HEAD")){
                                    if (response(buf, path, client_sock)){
                                        send(client_sock, "HTTP/1.1 404 Not Found\r\n\r\n", 30, 0);
                                        fprintf(stdout, "HTTP/1.1 404 Not Found\r\n\r\n");
                                    }
                                    else{
                                
                                    send(client_sock, buf, strlen(buf), 0);
                                    fprintf(stdout, "HEAD OK\r\n\r\n");
                                    }                            
                        }    
                        else if(!strcmp(request->http_method,"POST")){
                                    send(client_sock, buf, strlen(buf), 0);
                                    fprintf(stdout, "POST OK\r\n\r\n");
                                    
                        }
                        else{
                            fprintf(stderr,"wrong with identify methods!");
                        } 
                    }
                    else{
                        send(client_sock, "HTTP/1.1 501 Not Implemented\r\n\r\n", 32, 0);
                        fprintf(stdout, "HTTP/1.1 501 Not Implemented\r\n\r\n");
                    }
                }
                if(strlen(buff) < 5){
                    if(request != NULL){
                        free(request);
                        free(request->headers);
                    }
                    memset(buff, 0, BUF_SIZE);
                    break;
                }
                else{
                    if(request != NULL){
                        free(request);
                        free(request->headers);
                    }
                    strcpy(buf, buff);
                    memset(buff, 0, BUF_SIZE);
                }
            }
            memset(buf, 0, BUF_SIZE);
            readret[0] = 0;
        }
    return 0;
}

int close_socket(int sock)
{
    if (close(sock))
    {
        fprintf(stderr, "Failed closing socket.\n");
        return 1;
    }
    return 0;
}

int main(int argc, char* argv[])
{
    int sock, client_sock;
    ssize_t readret[1] = {0};
    socklen_t cli_size;
    struct sockaddr_in addr, cli_addr;
    char buf[BUF_SIZE];
    struct timeval timeout;
    int request_cnt[1] = {0};

    fprintf(stdout, "========== Liso Server ==========\n");

    /* all networked programs must create a socket */
    if ((sock = socket(PF_INET, SOCK_STREAM, 0)) == -1)
    {
        fprintf(stderr, "Failed creating socket.\n");
        return EXIT_FAILURE;
    }

    addr.sin_family = AF_INET;
    addr.sin_port = htons(ECHO_PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    /* servers bind sockets to ports---notify the OS they accept connections */
    if (bind(sock, (struct sockaddr *) &addr, sizeof(addr)))
    {
        close_socket(sock);
        fprintf(stderr, "Failed binding socket.\n");
        return EXIT_FAILURE;
    }


    if (listen(sock, MAX_CLIENTS))
    {
        close_socket(sock);
        fprintf(stderr, "Error listening on socket.\n");
        return EXIT_FAILURE;
    }

    /* finally, loop waiting for input and then write it back */
    fd_set current_sockets, ready_sockets;
    FD_ZERO(&current_sockets);
    FD_SET(sock,&current_sockets);
    timeout.tv_sec = 1;
    timeout.tv_usec = 500000;

    while (1)
    {
        ready_sockets = current_sockets;
        int ready_num = select(FD_SETSIZE,&ready_sockets,NULL,NULL,&timeout);

        if(ready_num < 0){
        fprintf(stderr,"Error select.\n");
        return EXIT_FAILURE;
        }
        for(int i = 0; i < FD_SETSIZE; i ++){
            if(FD_ISSET(i, &ready_sockets)){
                if(i == sock){
                    cli_size = sizeof(cli_addr);
                    if ((client_sock = accept(sock, (struct sockaddr *) &cli_addr,&cli_size)) == -1){
                        fprintf(stderr, "Error accepting connection.\n");
                        break;
                    }
                    FD_SET(client_sock,&current_sockets);
                }
                else{

                    fcntl(i,F_SETFL,fcntl(i,F_GETFL)|O_NONBLOCK);
                    handle_request(buf, i, readret);
                    int flags = fcntl(i,F_GETFL,0);
                    flags &= ~O_NONBLOCK;
                    fcntl(i,F_SETFL,flags);

                    FD_CLR(i, &current_sockets);
                    if(close_socket(i)){
                        fprintf(stderr, "Error closing client socket.\n");
                    }
                }
            }
        }
        if(client_sock == -1) break;
        timeout.tv_sec = 0;
        timeout.tv_usec = 500000;
    }

    close_socket(sock);

    return EXIT_SUCCESS;
}
