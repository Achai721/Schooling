#ifndef _LOG_H_
#define _LOG_H_
#include <string.h>

#define STR_COMM_SIZE 128
#define STR_MAX_SIZE 1024

#define MAX_LOG_FILE_NUM (3)

#define NUMBER(type) sizeof(type) / sizeof(type[0])

#define __FILENAME__ (strrchr(__FILE__, '/') ? (strrchr(__FILE__, '/') + 1) : __FILE__)

enum
{
    LOG_DEBUG = 0,
    LOG_ERROR,
    LOG_WARNING,
    LOG_ACTION,
    LOG_SYSTEM,
    BUTTOM
};

#define PRINT_LOG_TO_TERM (0)
#define PRINT_LOG_TO_FILE (1)

#define DEBUG_PRINT 0
#define LOG_DB(fmt, ...)                                                                                                                               \
    do                                                                                                                                                 \
    {                                                                                                                                                  \
        if (DEBUG_PRINT)                                                                                                                               \
        {                                                                                                                                              \
            if (PRINT_LOG_TO_TERM == g_ulPrintLogPlaceFlag)                                                                                            \
            {                                                                                                                                          \
                unsigned char ucLogInfo[STR_MAX_SIZE] = {0};                                                                                           \
                snprintf((char *)ucLogInfo, sizeof(ucLogInfo) - 1, fmt "[%s] [line:%d] [%s]\n", ##__VA_ARGS__, __FILENAME__, __LINE__, __FUNCTION__);  \
                LOG_PrintLog(LOG_DEBUG, ucLogInfo);                                                                                                    \
            }                                                                                                                                          \
            else                                                                                                                                       \
            {                                                                                                                                          \
                unsigned char ucLogInfo[STR_MAX_SIZE] = {0};                                                                                           \
                snprintf((char *)ucLogInfo, sizeof(ucLogInfo) - 1, fmt " [%s] [line:%d] [%s]\n", ##__VA_ARGS__, __FILENAME__, __LINE__, __FUNCTION__); \
                LOG_PrintLog(LOG_DEBUG, ucLogInfo);                                                                                                    \
            }                                                                                                                                          \
        }                                                                                                                                              \
    } while (0);

#define LOG_ERR(fmt, ...)                                                                    \
    do                                                                                       \
    {                                                                                        \
        printf("[ERROR]  " fmt "  [line:%d] [%s]\n", ##__VA_ARGS__, __LINE__, __FUNCTION__); \
    } while (0);

extern unsigned long g_ulPrintLogPlaceFlag;

unsigned long LOG_PrintLog(unsigned char ucType, unsigned char *pucLogInfo);

#define LOG_PRINT(type, fmt, ...)                                                                                                                   \
    do                                                                                                                                              \
    {                                                                                                                                               \
        if (PRINT_LOG_TO_TERM == g_ulPrintLogPlaceFlag)                                                                                             \
        {                                                                                                                                           \
            unsigned char ucLogInfo[STR_MAX_SIZE] = {0};                                                                                            \
            snprintf((char *)ucLogInfo, sizeof(ucLogInfo) - 1, fmt "  [%s] [line:%d] [%s]\n", ##__VA_ARGS__, __FILENAME__, __LINE__, __FUNCTION__); \
            LOG_PrintLog(type, ucLogInfo);                                                                                                          \
        }                                                                                                                                           \
        else                                                                                                                                        \
        {                                                                                                                                           \
            unsigned char ucLogInfo[STR_MAX_SIZE] = {0};                                                                                            \
            snprintf((char *)ucLogInfo, sizeof(ucLogInfo) - 1, fmt "  [%s] [line:%d] [%s]\n", ##__VA_ARGS__, __FILENAME__, __LINE__, __FUNCTION__); \
            LOG_PrintLog(type, ucLogInfo);                                                                                                          \
        }                                                                                                                                           \
    } while (0)

extern void LOG_SetPrintDebugLogFlag(unsigned long flag);
extern void LOG_SetPrintLogPlaceFlag(unsigned long flag);

extern unsigned long LOG_Init( unsigned char *ucLogFileName, unsigned long ulFileSize);
extern void LOG_Destroy(void);

#endif
