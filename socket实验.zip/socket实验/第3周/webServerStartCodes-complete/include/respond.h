#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#include <time.h>
#include <dirent.h>
//#include <string.h>
#include <libgen.h>
#include "parse.h"

#define GET "GET"
#define HEAD "HEAD"
#define POST "POST"

enum
	{
		STATE_UNKNOW = 0,
		STATE_GET,
		STATE_HEAD,
		STATE_POST
	};

enum{
	TEXT=0,
	IMAGE,
	APPLICATION,
	AUDIO,
	FONT,
	CHEMICAL,
	MODEL,
	VIDEO
};

typedef struct 
{
	//char header_name[4096];
	char header_value[4096];
}Respond_headers;

typedef struct{
	char respond_line[4096];
	Respond_headers* headers;
	int header_count;
	int content_length;
	char message_body[9999];
	char type;
}Respond;


int process_method(char []);
int match_version(char []);
int file_status(char PATH[],int client_sock);
int ident_type(char* suffix);
Respond* init_respond();
void free_respond(Respond *respond);

void respond_GET_200(Respond* respond,char PATH[]);
void respond_HEAD_200(Respond* respond,char PATH[]);
void respond_400(Respond* respond);
void respond_404(Respond* respond);
void respond_501(Respond* respond);
void respond_505(Respond* respond);
void respond2buf(Respond* respond,char *buf);

void request2respond(Respond *respond, Request *request, char *buf, int client_sock);